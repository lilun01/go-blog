package api

var API = &Api{}

type Api struct {
}
