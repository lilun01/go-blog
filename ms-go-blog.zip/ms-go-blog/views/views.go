package views

var HTML = &HTMLApi{}
type HTMLApi struct {

}
